import { Component, OnInit, ChangeDetectorRef, ViewChild } from "@angular/core";
import { DataModel } from "./app.model";
import { AppService } from "./app.service";
import { ToastrService } from "ngx-toastr";

@Component({
  selector: "app-root",
  templateUrl: "./app.component.html",
  styleUrls: ["./app.component.css"]
})
export class AppComponent implements OnInit {
  public addEmployee = false;
  public empData: DataModel[];
  public editItem: DataModel = {
    id: 0,
    name: "",
    lastName: "",
    email: "",
    mobileNo: "",
    isActive: true
  };
  public headElements = [
    "First Name",
    "Last Name",
    "Email Id",
    "Mobile No",
    "Actions"
  ];

  constructor(
    private _appService: AppService,
    private _toastrService: ToastrService
  ) {}

  ngOnInit() {
    this.empData = this.getEmpData();
  }

  getEmpData(): any[] {
    //Get Emp Data using service
    let returnData: DataModel[] = [];
    this._appService.getData().subscribe(
      res => {
        returnData = res;
        //console.log(this.empData);
      },
      err => {
        console.log(err);
      }
    );
    return returnData.sort(function(a, b) {
      return a.id - b.id;
    });
  }

  addEmp() {
    this.initDataModel();
    this.addEmployee = true;
  }

  initDataModel() {
    this.editItem = {
      id: 0,
      name: "",
      lastName: "",
      email: "",
      mobileNo: "",
      isActive: true
    };
  }

  saveEmpData() {
    if (this.dataVerification()) {
      if (this.editItem.id != 0) {
        this.updateEmpData(this.editItem.id);
      } else {
        this.editItem.id = this.empData.length + 1;
        this.editItem.isActive = true;
        this.empData.push(this.editItem);
        this._appService.saveData(this.empData);
        this._toastrService.success("Employee Added Successfully");
        this.initDataModel();
        this.addEmployee = false;
      }
    }
  }

  dataVerification(): boolean {
    if (
      this.editItem.name == "" ||
      this.editItem.lastName == "" ||
      this.editItem.email == "" ||
      this.editItem.mobileNo == ""
    ) {
      this._toastrService.error("Please fill all the details");
      return false;
    }
    
    if (this.editItem.mobileNo.toString().length != 10) {
      this._toastrService.error("Please enter 10 digit mobile no");
      return false;
    }
    return true;
  }

  updateEmpData(dataItemId: number) {
    this.empData = this.empData.filter(function(element) {
      return element.id != dataItemId;
    });
    this.empData.push(this.editItem);
    this._appService.saveData(this.empData);
    this._toastrService.success("Updated Successfully");

    this.initDataModel();
    this.addEmployee = false;
  }

  deleteEmpData(dataItemId: number) {
    this.empData = this.empData.filter(function(element) {
      return element.id != dataItemId;
    });
    this._appService.saveData(this.empData);
    this._toastrService.success("Deleted Successfully");
  }
}

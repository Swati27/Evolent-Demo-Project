export interface DataModel{
    id:number;
    name:string;
    lastName:string;
    email:string;
    mobileNo:string;
    isActive:boolean;
}
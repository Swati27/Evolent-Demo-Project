import { Injectable } from '@angular/core';
import { DataModel } from './app.model'
import { Observable, of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AppService {

  public initData:DataModel[] = [
    {
      id:1,
      name: "Rony",
      lastName: "Dsilva",
      email: "rony.dsilve@gmail.com",
      mobileNo: "7788996655",
      isActive: true
    },
    {
      id:2,
      name: "John",
      lastName: "Ferro",
      email: "john.ferro@gmail.com",
      mobileNo: "7788991122",
      isActive: true
    }
  ];

  constructor() {
    this.setData();
  }

  setData(){
    localStorage.setItem("empData",JSON.stringify(this.initData));
  }

  getData():Observable<any[]>{
    return of(JSON.parse(localStorage.getItem("empData")));
  }

  saveData(data:DataModel[]){
    localStorage.setItem("empData",JSON.stringify(data));
  }

}
